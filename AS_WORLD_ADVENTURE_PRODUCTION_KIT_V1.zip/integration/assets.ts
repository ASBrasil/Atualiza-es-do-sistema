// Drop-in loader map for AS World Adventure
export const ASWorldAssets = {
  logo: "/game-universe/world-adventure/branding/as-brasil-logo.png",
  cities: {
    rio: "/game-universe/world-adventure/backgrounds/rio",
    "sao-paulo": "/game-universe/world-adventure/backgrounds/sao-paulo",
    brasilia: "/game-universe/world-adventure/backgrounds/brasilia",
  },
  characters: "/game-universe/world-adventure/characters",
  enemies: "/game-universe/world-adventure/enemies",
  bosses: "/game-universe/world-adventure/bosses",
  collectibles: "/game-universe/world-adventure/collectibles",
  powerups: "/game-universe/world-adventure/powerups",
  props: "/game-universe/world-adventure/props",
  ui: "/game-universe/world-adventure/ui",
  effects: "/game-universe/world-adventure/effects",
};
