# AS WORLD ADVENTURE — PRODUCTION KIT V1

Este ZIP contém arquivos físicos separados para integração: logo oficial, 3 cenários,
6 layers por cidade, tilesets por cidade, 168 frames RGBA dos 7 personagens + strips,
inimigos, bosses, coletáveis, power-ups, props, HUD/UI, efeitos, SFX, manifest e loader.

## Instalação
Copiar o conteúdo para:
`public/game-universe/world-adventure/`

## Claude
1. Leia `data/manifest.json`.
2. Use `integration/assets.ts` como mapa de paths.
3. Renderize os 6 layers de cada cidade com velocidades diferentes.
4. Use os frames em `characters/<nome>/<estado>/`.
5. Use a logo oficial fornecida em `branding/as-brasil-logo.png`.
6. Não substitua os assets por placeholders.
